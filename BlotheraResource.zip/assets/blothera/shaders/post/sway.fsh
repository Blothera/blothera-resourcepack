#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(std140) uniform SwayConfig {
    vec4 Wave;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

const float TAU = 6.2831853;

void main() {
    float t = TAU * Wave.y * GameTime;
    vec2 shift = vec2(sin(t + texCoord.y * 6.0), cos(t * 0.7 + texCoord.x * 4.0)) * Wave.x;
    vec2 at = clamp(texCoord + shift, 0.0, 1.0);
    vec3 colour = texture(InSampler, at).rgb;
    vec2 ghostShift = vec2(sin(t * 0.5), cos(t * 0.37)) * Wave.z;
    vec3 ghost = texture(InSampler, clamp(at + ghostShift, 0.0, 1.0)).rgb;
    fragColor = vec4(mix(colour, ghost, Wave.w), 1.0);
}
