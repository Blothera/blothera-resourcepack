#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(std140) uniform GrainConfig {
    vec4 Grain;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
    vec3 colour = texture(InSampler, texCoord).rgb;
    float frame = floor(GameTime * Grain.y);
    float noise = hash(floor(texCoord * ScreenSize) + vec2(frame * 17.0, frame * 31.0)) - 0.5;
    fragColor = vec4(clamp(colour + noise * Grain.x, 0.0, 1.0), 1.0);
}
