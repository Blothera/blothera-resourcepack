#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(std140) uniform VignetteConfig {
    vec4 Tint;
    vec4 Shape;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

const float TAU = 6.2831853;

void main() {
    vec3 colour = texture(InSampler, texCoord).rgb;
    vec2 fromCentre = (texCoord - 0.5) * vec2(ScreenSize.x / max(ScreenSize.y, 1.0), 1.0);
    float edge = smoothstep(Shape.x, Shape.y, length(fromCentre));
    float strength = Tint.a;
    if (Shape.z > 0.0) {
        float beat = 0.5 + 0.5 * sin(TAU * Shape.z * GameTime);
        strength *= 1.0 - Shape.w + Shape.w * beat * beat;
    }
    fragColor = vec4(mix(colour, Tint.rgb, clamp(edge * strength, 0.0, 1.0)), 1.0);
}
